# Define the path to the directory where all programs are located
$databasePath = "C:\ProgramData\DIEBOLD\AutomationFrontend"
$databaseFile = $databasePath+"\Automation.db"

Write-Host "Executing Database Removal"
# Output the directory
Write-Host "Script directory: $PSScriptRoot"

# Get the version and start the execution
$returnvalue =  Get-Content $PSScriptRoot\delete_tables.sql | sqlite3 $databaseFile
Write-Host $returnvalue


