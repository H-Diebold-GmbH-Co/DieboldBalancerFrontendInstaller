# Define the path to the directory where all programs are located
$databasePath = "C:\ProgramData\DIEBOLD\AutomationFrontend"
$databaseFile = $databasePath+"\Automation.db"
$latestVersion = 1.0

Write-Host "Executing Database Update"
# Output the directory
Write-Host "Script directory: $PSScriptRoot"

#create directory if not existent
if (-not (Test-Path -Path $databasePath)) {
    Write-Host "Creating Database Path."
    New-Item -Path $databasePath -ItemType Directory
    New-Item -Path $databasePath\logs -ItemType Directory
}

# Get the version and start the execution
$version =  Get-Content $PSScriptRoot\get_version.sql | sqlite3 $databaseFile
$versionFloat = [float]$version

if ($versionFloat -eq $latestVersion) {
    Write-Host "Database already latest version: $latestVersion"
}
else {
    Write-Host "Updating from version $versionFloat to version $latestVersion"
}

#create Database if it doesn't exist yet
if ($versionFloat -lt 1.0) {
    Write-Host "Creating database v1."
    Get-Content $PSScriptRoot\create_tables_v1.sql | sqlite3 $databaseFile
}

#if version is less than 1.x make the sequential update
if ($versionFloat -lt 1.1) {
    Write-Host "Updating Database to v1.1"
    Get-Content $PSScriptRoot\update_v1.1.sql | sqlite3 $databaseFile
}
if ($versionFloat -lt 1.2) {
    Write-Host "Updating Database to v1.2"
    Get-Content $PSScriptRoot\update_v1.2.sql | sqlite3 $databaseFile
}
if ($versionFloat -lt 1.3) {
    Write-Host "Updating Database to v1.3"
    Get-Content $PSScriptRoot\update_v1.3.sql | sqlite3 $databaseFile
}

