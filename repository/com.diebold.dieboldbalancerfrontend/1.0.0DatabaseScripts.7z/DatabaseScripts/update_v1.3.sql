SELECT 'Update to v1.3 completed';

UPDATE versioning SET version=1.3 WHERE id = 1;

ALTER TABLE tools ADD fixedDrillParams Text;