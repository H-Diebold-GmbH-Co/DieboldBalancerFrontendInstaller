UPDATE versioning SET version=1.1 WHERE id = 1;

ALTER TABLE drills ADD counter INTEGER DEFAULT 0 NOT NULL;