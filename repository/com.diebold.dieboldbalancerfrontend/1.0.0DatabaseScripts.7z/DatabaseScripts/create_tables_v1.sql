PRAGMA foreign_keys=on;


CREATE TABLE IF NOT EXISTS materials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    density REAL NOT NULL,
    default_entry INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS tools (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    description TEXT,
    diameter_lower REAL NOT NULL,
	diameter_upper REAL NOT NULL,
    height_lower INTEGER NOT NULL,
	height_upper INTEGER NOT NULL,
    material_id INTEGER NOT NULL,
    picture_name TEXT DEFAULT '',
    max_drill_depth_lower FLOAT NOT NULL,
	max_drill_depth_upper FLOAT NOT NULL,
    default_entry INTEGER NOT NULL,
    default_compensation_method INTEGER NOT NULL,
    dynamic_balancing INTEGER NOT NULL,
    tolerance_lower REAL NOT NULL,
    tolerance_upper REAL NOT NULL,
    tolerance_static REAL NOT NULL,
    adapter INTEGER NOT NULL,
    mass REAL NOT NULL,
    tool_speed INTEGER NOT NULL,
    measure_speed INTEGER NOT NULL,
    max_diameter REAL NOT NULL,
	max_height FLOAT NOT NULL,
    red_zone TEXT NOT NULL,
    default_drill INTEGER NOT NULL,
	default_measure_method INTEGER NOT NULL,
	default_tolerance_method INTEGER NOT NULL,
	g_class REAL,
	screw_set INTEGER NOT NULL,
	screw_depth_lower REAL NOT NULL,
	screw_depth_upper REAL NOT NULL,
	fixed_weight_outer_diameter REAL NOT NULL,
	fixed_weight REAL NOT NULL,
    FOREIGN KEY (default_drill)
    REFERENCES drills(id),
    FOREIGN KEY (material_id)
    REFERENCES materials(id),
	FOREIGN KEY (screw_set)
    REFERENCES screw_sets(id)
);

CREATE TABLE IF NOT EXISTS drills (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    diameter REAL NOT NULL,
    angle INTEGER NOT NULL,
    default_entry INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS licenses (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    license_hash INTEGER NOT NULL,
    active INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    can_edit_tools INTEGER NOT NULL,
    can_edit_settings INTEGER NOT NULL,
    is_service_user INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    password_hash INTEGER NOT NULL,
    group_id INTEGER NOT NULL,
    default_entry INTEGER NOT NULL,
    FOREIGN KEY (group_id)
    REFERENCES groups(id)
);


CREATE TABLE IF NOT EXISTS versioning (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    version REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS drill_logs (
    user_id INTEGER,
    tool_id INTEGER,
    count INTEGER NOT NULL,
    last_used_data TEXT NOT NULL,
    FOREIGN KEY (user_id)
    REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (tool_id)
    REFERENCES tools(id) ON DELETE CASCADE,
    PRIMARY KEY(user_id, tool_id)
);


CREATE TABLE IF NOT EXISTS drill_parameters (
    drill_id INTEGER,
    material_id INTEGER,
    spindle_rpm INTEGER NOT NULL,
    axis_velocity FLOAT NOT NULL,
    default_entry INTEGER NOT NULL,
    FOREIGN KEY (drill_id)
    REFERENCES drills(id) 
    ON DELETE CASCADE,
    FOREIGN KEY (material_id)
    REFERENCES materials(id) 
    ON DELETE CASCADE,
    PRIMARY KEY(drill_id, material_id) 
);


CREATE TABLE IF NOT EXISTS screw_sets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    thread_size REAL NOT NULL,
    weights TEXT NOT NULL,
    default_entry INTEGER NOT NULL
);

INSERT INTO versioning (version) VALUES(1.0);
INSERT INTO groups (name, can_edit_tools, can_edit_settings, is_service_user) VALUES 
('Worker',0,0,0),
('Supervisor',1,0,0),
('Administrator',1,1,0),
('Service',1,1,1);
INSERT INTO users(name, password_hash, group_id, default_entry) VALUES ('admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 3, 1);
INSERT INTO materials (name,density,default_entry) VALUES 
('Steel', 0.00785, 1),
('Copper', 0.00896, 1),
('Aluminium', 0.0026989, 1);
INSERT INTO drills (name,diameter,angle,default_entry) VALUES
('Drill03',3,140,1);
INSERT INTO drill_parameters (drill_id, material_id,spindle_rpm,axis_velocity,default_entry) VALUES
(1,1,1700,90,1);

INSERT INTO screw_sets (name,thread_size,weights,default_entry) VALUES
('Default Screws',3,'0.43,4,0.52,4.5,0.6,5,0.67,5.25,0.77,6,0.86,6.5,0.93,7,1.03,7.2,1.09,8',1);
