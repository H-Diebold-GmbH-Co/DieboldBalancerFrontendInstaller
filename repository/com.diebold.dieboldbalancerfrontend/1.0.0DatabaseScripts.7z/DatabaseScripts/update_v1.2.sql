SELECT 'Update to v1.2 completed';

UPDATE versioning SET version=1.2 WHERE id = 1;

ALTER TABLE tools ADD referenceMapping Text;